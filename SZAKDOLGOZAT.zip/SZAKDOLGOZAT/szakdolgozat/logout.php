<?php
session_start();

echo "<script>alert('Sikeres Kijelentkezés!')</script>";
session_destroy(); //befejezi a sessiont
header("Location: index.php");
?>