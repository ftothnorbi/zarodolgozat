<?php
include('login.php'); // Includes Login Script
if (isset($_SESSION['logged_in'])) {
    header("location: home.php?page=currjob"); // Redirecting To Profile Page
}
?>
<!-- ---------------------------------------------------------------- -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="./css/index.css" type="text/css">
</head>

<body>
    <div class="bg" style="width: 100%; height: 100%">
        <img class="bg" alt="mechanic background" src="./images/login_bg.jpg" width="1920" height="1080" />
    </div>
    <form action="" method="post" class="login-form">
        <img src="./images/login_avatar.jpg" class="avatar">
        <br>
        <input type="text" name="username-data" placeholder="felhasználónév" id="username">
        <br>
        <input type="password" name="password-data" placeholder="jelszó" id="password">
        <button class="btn" name="submit" type="submit">Bejelentkezés</button>
        <!-- <div class="other">
            <div class="reg"><a>Elfelejtett jelszó</a></div>
        </div> -->
    </form>
</body>
</html>