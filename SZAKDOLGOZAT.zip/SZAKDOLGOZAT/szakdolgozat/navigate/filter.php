<?php
include('dbconn.php');
$conn=connectionOpen();
if($_POST){
                    $sql_car = "SELECT * FROM car WHERE lincense_plate LIKE '%".$_POST['lincense_plate']."%' LIMIT 1";
                    
                    $query_car = $conn->query($sql_car);    
                    
                    $carId = '';
                    $result_car = $query_car->fetch_object();
                    $carId = $result_car->car_id;

                    if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == "Mechanic"){
                        $sql = "SELECT * FROM repair WHERE repair_mechanic = '".$_SESSION['user_id']."' AND car_id = '".$carId."'";
                    }else{
                        $sql = "SELECT * FROM repair WHERE car_id = '".$carId."'";
                    }

                }else{
                    if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == "Mechanic"){
                        $sql = "SELECT * FROM repair WHERE repair_mechanic = " . $_SESSION['user_id'];
                    }else{
                        $sql = "SELECT * FROM repair";
                    }
                }
?>