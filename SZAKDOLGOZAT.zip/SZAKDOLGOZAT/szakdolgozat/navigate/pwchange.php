<?php
include('pwupdate.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jelszó megváltoztatás</title>
    <link rel="stylesheet" href="../css/">
</head>

<body>
    <form action="" method="post" class="pwchange-form">
        <label class="omrs-input-filled">
            <input type="text" name="username-data" id="username" required />
            <span class="omrs-input-label"></span>
            <span class="omrs-input-helper">Felhasználónév</span>
        </label>
        <br>
        <label class="omrs-input-filled">
            <input type="password" name="old-password-data" id="old-password" required />
            <span class="omrs-input-label"></span>
            <span class="omrs-input-helper">Régi jelszó</span>
        </label>
        <br>
        <label class="omrs-input-filled">
            <input type="text" pattern="/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$/" name="new-password-data" id="new-password" required />
            <span class="omrs-input-label"></span>
            <span class="omrs-input-helper">Új jelszó</span>
        </label>
        <br>
        <button class="btn" name="submit-pw" type="submit">Frissítés</button>
        <br>
        <h6>Minimum 8 karakter de Maximálisan 12, Legalább 1 Nagybetű, 1 Kisbetű, 1 Szám, 1 Speciális karakter -> !@#$%^&*_=+-</h6>
    </form>
</body>

</html>