<?php
function connectionOpen(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbName = "garage";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbName);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}
function connectionClose($conn){
    $conn->close();
}
?>

<!--
php kód elejére:
    include('dbconn.php');
    $conn=connectionOpen();

kapcsolat bezárása:
    connectionClose($conn);
-->