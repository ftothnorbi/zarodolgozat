<?php
    $error = "";
    include('dbconn.php');
    if (isset($_POST["submit-pw"])) {
        if (empty($_POST["username-data"] || empty($_POST["old-password-data"]) || empty($_POST["new-password-data"]))) {
            $error = "<script>alert('Hibás valami')</script>";
        }else {
            $old_username = $_POST["username-data"];
            $old_password = $_POST["old-password-data"];
            $new_password = $_POST["new-password-data"];
            $newHashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

            $conn=connectionOpen();
            //régi jelszó check
            $query = mysqli_query($conn, "SELECT username, password  FROM userTable WHERE username = '" . $_SESSION['login_user'] ."'");
            $result = mysqli_fetch_object($query);

            if (password_verify($old_password, $result->password)) {
                $newpw_query = mysqli_query($conn, "UPDATE userTable SET password = '". $newHashedPassword ."' WHERE username = '". $old_username ."' ");
                
                echo "<script>alert('Sikeres jelszó módosítás')</script>";
            }
        }
    }
?>
