<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Munkák törlése</title>
    <style>
        .page-wrapper {
  height: 100vh;
  margin: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-flow: row wrap;
  background-color: #e3e7ea;
}
.btn-round {
  width: 60px;
  height: 60px;
  margin: 10px;
  border-radius: 50%;
}

.btn-wide {
  width: 300px;
  height: 60px;
  margin: 10px;
  border-radius: 50px;
  font-size: 18px;
  color: #708090;
  
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-normal {
  box-shadow: -3px -3px 7px #f5f5f5, 3px 3px 7px #bbc3cc;
}

.btn-pressed {
  box-shadow: -3px -3px 7px #f5f5f5 inset, 3px 3px 7px #bbc3cc inset;
}

.btn-normal:hover {
  box-shadow: -3px -3px 7px #f5f5f5 inset, 3px 3px 7px #bbc3cc inset;
  font-size: 16px;
  user-select: none;
}

/* checkbox */
.checkbox {
    width: 20px;
    height: 20px;
}
    </style>
</head>

<body>
    <div class="search">
        <form action="navigate/delete.php" method="POST">
            <button type="submit" class="delete-btn" name="submit">Törlés</button>
            <!-- <button type="submit" class="btn-insert" name="submit">SUBMIT</button> -->
        
    </div>
    <div class="jobs">
        <ul class="ul-sticky">
            <?php
            //* Minden munka megjelenítése szerelők által rendszerezve
            include('dbconn.php');
            $conn = connectionOpen();

            $sql = "SELECT * FROM repair WHERE deleted = 0";
            $query = $conn->query($sql);
            while ($result = $query->fetch_object()) {
                //echo $result->repair_id;
                $sql = 'SELECT * FROM car WHERE car_id =' . $result->car_id;
                $query2 = $conn->query($sql);

                if ($query2->num_rows > 0) {
                    $result2 = $query2->fetch_object();
                    $sql = 'SELECT * FROM customer WHERE cus_id =' . $result2->car_cus_id;
                    $query3 = $conn->query($sql);
                    if ($query3->num_rows > 0) {
                        $result3 = $query3->fetch_object();
                        $sql = "SELECT userTable.name FROM userTable INNER JOIN repair ON(repair.repair_mechanic = userTable.user_id) WHERE repair.repair_mechanic = '" . $result->repair_mechanic . "' LIMIT 1";
                        $query4 = $conn->query($sql);
                        $result4 = $query4->fetch_object();
                        echo '
                    <li class="li-sticky">
                        <p>' . $result4->name . '</p>
                        <input type="checkbox" class="checkbox" name="checked[]" value="'.$result2->car_id.'" >

                        <a href="?page=repair&id=' . $result->repair_id . '" class="a-sticky">
                        <h2 class="h2-sticky">' . $result2->lincense_plate . '</h2>
                        <h2 class="h2-sticky">' . $result2->brand . ' ' . $result2->model . ' ' . $result2->year_of_manufacture . '</h2>
                        <p class="p-sticky">' . $result3->cus_name . '</p>
                        <p class="p-sticky">' . $result->repair_timestamp . '</p>
                        <p class="p-sticky">' . $result->repair_description . '</p>
                        </a>
                    </li>';
                    }
                }
            }
            connectionClose($conn);
            ?>
        </ul>
    </div>
    </form>
</body>

</html>