<?php
    echo '<div class="search">
        <form action="home.php?page=service" method="POST">
            <input type="text" name="lincense_plate" placeholder="Rendszám.." required />
            <button type="submit" name="submit-filter2" class="search-btn">szűrés</button>
        </form>
    </div>
    <div class="jobs">
        <ul class="ul-sticky">';
            //* Minden eddigi hozzáadott munka megjelenítése szerelők által rendszerezve
            include('dbconn.php');
            $conn = connectionOpen();
            if(isset($_POST['submit-filter2'])){
                $sql_car = "SELECT * FROM car WHERE lincense_plate LIKE '%".$_POST['lincense_plate']."%' ";
                echo $sql_car;
                $query_car = $conn->query($sql_car);    
                if ($query_car->num_rows == 0) {
                    echo 'Nincs a szűrésnek megfelelő munka!';
                }else{
                $carId = '';
                while($result_car = $query_car->fetch_object()){

                $carId = $result_car->car_id;

                if(isset($_SESSION['user_role']) && $_SESSION['user_role'] == "Mechanic"){
                    $sql = "SELECT * FROM repair WHERE repair_mechanic = '".$_SESSION['user_id']."' AND car_id = '".$carId."'";
                }else{
                    $sql = "SELECT * FROM repair WHERE car_id = '".$carId."'";
                }
                $query = $conn->query($sql);
                while ($result = $query->fetch_object()) {
                    $sql = 'SELECT * FROM customer WHERE cus_id =' .$result_car->car_cus_id;
                    $query3 = $conn->query($sql);
                    if ($query3->num_rows > 0) {
                    $result3 = $query3->fetch_object();
                    echo '
                    <li class="li-sticky">
                        <a href="?page=currjob/currjobview" class="a-sticky">
                        <h2 class="h2-sticky">'.$result_car->lincense_plate.'</h2>
                        <h2 class="h2-sticky">'.$result_car->brand . ' ' . $result_car->model.' '.$result_car->year_of_manufacture.'</h2>
                        <p class="p-sticky">'.$result3->cus_name.'</p>
                        <p class="p-sticky">'.$result->repair_timestamp.'</p>
                        <p class="p-sticky">'.$result->repair_description.'</p>
                        </a>
                    </li>';
                    }
                }
            }
            }
            }else{

            $sql = "SELECT * FROM repair";
            $query = $conn->query($sql);
            while ($result = $query->fetch_object()) {
                //echo $result->repair_id;
                $sql = 'SELECT * FROM car WHERE car_id =' . $result->car_id;
                $query2 = $conn->query($sql);

                if ($query2->num_rows > 0) {
                    $result2 = $query2->fetch_object();
                    $sql = 'SELECT * FROM customer WHERE cus_id =' . $result2->car_cus_id;
                    $query3 = $conn->query($sql);
                    if ($query3->num_rows > 0) {
                        $result3 = $query3->fetch_object();
                        $sql = "SELECT userTable.name FROM userTable INNER JOIN repair ON(repair.repair_mechanic = userTable.user_id) WHERE repair.repair_mechanic = '" . $result->repair_mechanic . "' LIMIT 1";
                        $query4 = $conn->query($sql);
                        $result4 = $query4->fetch_object();
                        echo '
                    <li class="li-sticky">
                        <p>' . $result4->name . '</p>
                        <a href="?page=repair&id=' . $result->repair_id . '" class="a-sticky">
                        <h2 class="h2-sticky">' . $result2->lincense_plate . '</h2>
                        <h2 class="h2-sticky">' . $result2->brand . ' ' . $result2->model . ' ' . $result2->year_of_manufacture . '</h2>
                        <p class="p-sticky">' . $result3->cus_name . '</p>
                        <p class="p-sticky">' . $result->repair_timestamp . '</p>
                        <p class="p-sticky">' . $result->repair_description . '</p>
                        </a>
                    </li>';
                    }
                }
            }
            connectionClose($conn);
        }
echo' </ul>
    </div>
    </form>';
?>