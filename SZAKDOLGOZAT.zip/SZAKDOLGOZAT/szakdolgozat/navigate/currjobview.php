<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jelenlegi Munkák Infó</title>
</head>
<body>
    <?php
    include('dbconn.php');
    $conn=connectionOpen();

    $sql = "SELECT * FROM repair WHERE deleted = 0";
    $query = $conn->query($sql);
    ?>
        <div class="container">
        <div>
            <h4 class="title">Ügyfél adatok:</h4>
        
                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <?php
                        $sql = "SELECT cus_name FROM customer";
                        $query = $conn->query($sql);
                        echo '<input type="text" placeholder='"."$query"."' name="cus_name" id="cus_name"/>';
                        ?>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Tulajdonos teljes neve</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" name="cus_address" id="cus_address"/>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Lakcím</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" name="cus_mobile" id="cus_mobile"/>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Telefonszám</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" name="cus_email" id="cus_email"/>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Email</span>
                    </label>
                </div>
            
        </div>
        <div class="car">
            <h4 class="title">Autó adatok:</h4>
                <div class="car-left">
                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="lincense_plate" id="lincense_plate"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Rendszám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="brand" id="brand"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Márka</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="model" id="model"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Model</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="finish" id="finish"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Kivitel</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="year_of_manufacture" id="year_of_manufacture"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Gyártási év</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="cylinder_capacity" id="cylinder_capacity"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Hengerműtartalom</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="colour" id="colour"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Szín</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="warranty" id="warranty"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Garancia</span>
                        </label>
                    </div>
                </div>
                <div class="car-right">
                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="fuel_type" id="fuel_type"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Hajtóanyag</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="curr_condition" id="curr_condition"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Állapot</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="gearbox" id="gearbox"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Váltó típusa</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="chassis_num" id="chassis_num"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Alvázszám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="engine_num" id="engine_num"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Motorszám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="mileage_km" id="mileage_km"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">KM óra állása</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="doors" id="doors"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Ajtók száma</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="power_kw" id="power_kw"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Teljesítmény (kw)</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" name="gross_weight_kg" id="gross_weight_kg"/>
                            <span class="omrs-input-label"></span>
                            <span class="omrs-input-helper">Együttes tömeg (kg)</span>
                        </label>
                    </div>
                </div>
            
        </div>
        <div>
            <h4 class="title">Munka adatok:</h4>
                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" name="repair_description" id="repair_description"/>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Munkaleírás</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" name="repair_type" id="repair_type"/>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Munkatípus</span>
                    </label>
                </div>
                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <?php
                        //kell a repair_mechanid id-ja
                        $a_sql = "SELECT * FROM repair WHERE deleted = 0";
                        $a_query = $conn->query($a_sql);
                        $a_result = $a_query->fetch_object()

                        //kell a neve az adott repair_mechanicnak
                        $b_sql = "SELECT userTable.name FROM userTable INNER JOIN repair ON(repair.repair_mechanic = userTable.user_id) WHERE repair.repair_mechanic = '".$a_result->repair_mechanic."' LIMIT 1";
                        $b_query = $conn->query($b_sql);
                        $b_result = $b_query->fetch_object();
                        echo "<input type='text' name='repair_mechanic' id='repair_mechanic' value=''".$b_result->name."''/>";
                        
                        connectionClose($conn);
                        ?>
                        <span class="omrs-input-label"></span>
                        <span class="omrs-input-helper">Kiosztott szerelő</span>
                    </label>
                </div>

                
            </form>
        </div>
    </div>
</body>
</html>