<?php
if (isset($_POST['submit'])) {

    $server = "localhost";
    $usernames = "root";
    $password = "";
    $dbname = "garage";

    $conn = mysqli_connect($server, $usernames, $password, $dbname);

    # insert into customer table
    $cus_name = $_POST['cus_name'];
    $cus_address = $_POST['cus_address'];
    $cus_mobile = $_POST['cus_mobile'];
    $cus_email = $_POST['cus_email'];

    $cus_query = "INSERT INTO customer (cus_name, cus_address, cus_mobile, cus_email)
                      VALUES ('".$cus_name."', '".$cus_address."', '".$cus_mobile."', '".$cus_email."')";
    $response_Customer = mysqli_query($conn, $cus_query);
    
    if($response_Customer){
        $car_cus_id = $conn->insert_id;

        # insert into car table
        $lincense_plate = $_POST['lincense_plate'];
        $brand = $_POST['brand'];
        $model = $_POST['model'];
        $year_of_manufacture = $_POST['year_of_manufacture'];
        $finish = $_POST['finish'];
        $mileage_km = $_POST['mileage_km'];
        $curr_condition = $_POST['curr_condition'];
        $fuel_type = $_POST['fuel_type'];
        $cylinder_capacity = $_POST['cylinder_capacity'];
        $doors = $_POST['doors'];
        $gearbox = $_POST['gearbox'];
        $colour = $_POST['colour'];
        $warranty = $_POST['warranty'];
        $power_kw = $_POST['power_kw'];
        $chassis_num = $_POST['chassis_num'];
        $engine_num = $_POST['engine_num'];
        $gross_weight_kg = $_POST['gross_weight_kg'];

        $car_query = "INSERT INTO car (ar_cus_id, lincense_plate, brand, model, year_of_manufacture, finish, mileage_km, curr_condition, fuel_type, cylinder_capacity, doors, gearbox, colour, warranty, power_kw, chassis_num, engine_num, gross_weight_kg)
                    VALUES ($car_cus_id, '$lincense_plate', '$brand', '$model', '$year_of_manufacture', 
                    '$finish', '$mileage_km', '$curr_condition', '$fuel_type', '$cylinder_capacity',
                    '$doors', '$gearbox', '$colour', '$warranty', '$power_kw', '$chassis_num',
                    '$engine_num', '$gross_weight_kg')";
        $car_run = mysqli_query($conn, $car_query);
        if($car_run){
            
            $car_id = $conn->insert_id;

            # insert into repair table
            $repair_type = $_POST['repair_type'];
            $repair_description = $_POST['repair_description'];
            $repair_mechanic = $_POST['repair_mechanic'];

            $repair_query = "INSERT INTO repair (car_id, repair_type, repair_description, repair_mechanic)
                                VALUES ($car_id, '$repair_type', '$repair_description', '$repair_mechanic')";
            $repair_run = mysqli_query($conn, $repair_query);

            if ($repair_run) {
                echo "<h1>Form submitted successfully</h1>";
            }else {
                echo "<h1>Form not submitted successfully</h1>";
            }
        
        }else{
            echo("Error description: " . mysqli_error($conn));
        }
    }else{
        echo("Error description: " . mysqli_error($conn));
    }
    header("Location: ../home.php?page=newjob%2Fnew");
}