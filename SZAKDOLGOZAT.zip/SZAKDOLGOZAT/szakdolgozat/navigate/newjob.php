<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Job</title>

    <style>
        pattern:invalid{
            animation: shake 300ms;
        }
        @keyframes shake {
            25% { transform: translate(4px); }
            50% { transform: translate(-4px); }
            75% { transform: translate(4px); }
        }

        body {
  margin: 0;
}

.page-wrapper {
  height: 100vh;
  margin: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-flow: row wrap;
  background-color: #e3e7ea;
}
.btn-round {
  width: 60px;
  height: 60px;
  margin: 10px;
  border-radius: 50%;
}

.btn-wide {
  width: 300px;
  height: 60px;
  margin: 10px;
  border-radius: 50px;
  font-size: 18px;
  color: #708090;
  
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-normal {
  box-shadow: -3px -3px 7px #f5f5f5, 3px 3px 7px #bbc3cc;
}

.btn-pressed {
  box-shadow: -3px -3px 7px #f5f5f5 inset, 3px 3px 7px #bbc3cc inset;
}

.btn-normal:hover {
  box-shadow: -3px -3px 7px #f5f5f5 inset, 3px 3px 7px #bbc3cc inset;
  font-size: 16px;
  user-select: none;
}
    </style>
</head>

<body style="overflow: visible">
    <form method="post" action="navigate/insert.php">
    <div class="container">
        <div>
            <h4 class="title">Ügyfél adatok:</h4>
        
                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" pattern="^([A-Z]([a-záéúőóüö.]+\s?)[-]?){2,}$" class="regex" name="cus_name" id="cus_name" required />
                        <span class="omrs-input-label">Teljes név</span>
                        <span class="omrs-input-helper">pl. Gipsz Jakab</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" pattern="^[0-9]{4}\s{1}([A-ZÁÉÚŐÓÜÖ.]{1}[a-záéúőóüö.]+)\s{1}{1-4}(\b(utca|út|tér|köztér)){1}[0-9]{3}[.]{1}\s[1-9]{0,2}[.]{1}(\b(emelet)){1}\s" class="regex" name="cus_address" id="cus_address" required />
                        <span class="omrs-input-label">Lakcím</span>
                        <span class="omrs-input-helper">Pl. 1196 Budapest, Kossuth Tér 12.</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text"  class="regex" name="cus_mobile" id="cus_mobile" required />
                        <span class="omrs-input-label">Telefonszám</span>
                        <span class="omrs-input-helper">Pl. 06201234567</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="email" class="regex" name="cus_email" id="cus_email" required />
                        <span class="omrs-input-label">Email</span>
                        <span class="omrs-input-helper">Pl. valami@gmail.com</span>
                    </label>
                </div>
            
        </div>
        <div class="car">
            <h4 class="title">Autó adatok:</h4>
                <div class="car-left">
                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text"  class="regex" name="lincense_plate" id="lincense_plate" required />
                            <span class="omrs-input-label">Rendszám</span>
                            <span class="omrs-input-helper">A, ABC-123</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="brand" id="brand" required />
                            <span class="omrs-input-label">Márka</span>
                            <span class="omrs-input-helper">D.1, szöveg</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text"  class="regex" name="model" id="model" required />
                            <span class="omrs-input-label">Model</span>
                            <span class="omrs-input-helper">D.3, szöveg</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="finish" id="finish" required />
                            <span class="omrs-input-label">Kivitel</span>
                            <span class="omrs-input-helper">szöveg</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="year_of_manufacture" id="year_of_manufacture" required />
                            <span class="omrs-input-label">Gyártási év</span>
                            <span class="omrs-input-helper">évszám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="cylinder_capacity" id="cylinder_capacity" required />
                            <span class="omrs-input-label">Hengerműtartalom</span>
                            <span class="omrs-input-helper">P.1, szám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="colour" id="colour" required />
                            <span class="omrs-input-label">Szín</span>
                            <span class="omrs-input-helper">R, szöveg</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="warranty" id="warranty" required />
                            <span class="omrs-input-label">Garancia</span>
                            <span class="omrs-input-helper">R, szöveg</span>
                        </label>
                    </div>
                </div>
                <div class="car-right">
                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <select name="fuel_type" id="fuel_type" required>
                                <option value="null">Válassz:</option>
                                <option value="gasoline">Benzin</option>
                                <option value="diesel">Dízel</option>
                                <option value="electric">Elektromos</option>
                                <option value="hybrid">Hibrid</option>
                                <option value="LPG">Autógáz</option>
                            </select>
                            <span class="omrs-input-label">Hajtóanyag</span>
                            <span class="omrs-input-helper">P.3</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <select name="curr_condition" id="curr_condition" required>
                                <option value="null">Válassz:</option>
                                <option value="normal">Normál</option>
                                <option value="damaged">Sérült</option>
                                <option value="missing parts">Hiányos</option>
                                <option value="damaged headpiece">Fő darab sérült</option>
                            </select>
                            <span class="omrs-input-label">Állapot</span>
                            <span class="omrs-input-helper">Válassz</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <select name="gearbox" id="gearbox" required>
                                <option value="null">Válassz:</option>
                                <option value="manual">Manuális</option>
                                <option value="automatic">Automata</option>
                                <option value="semi-automatic">Fél-automata</option>
                                <option value="sequential">Szekvenciális</option>
                            </select>
                            <span class="omrs-input-label">Váltó típusa</span>
                            <span class="omrs-input-helper">Válassz</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="chassis_num" id="chassis_num" required />
                            <span class="omrs-input-label">Alvázszám</span>
                            <span class="omrs-input-helper">E, szám és szöveg</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="engine_num" id="engine_num" required />
                            <span class="omrs-input-label">Motorszám</span>
                            <span class="omrs-input-helper">P.5, szám és szöveg</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="mileage_km" id="mileage_km" required />
                            <span class="omrs-input-label">KM óra állása</span>
                            <span class="omrs-input-helper">szám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="doors" id="doors" required />
                            <span class="omrs-input-label">Ajtók száma</span>
                            <span class="omrs-input-helper">szám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="power_kw" id="power_kw" required />
                            <span class="omrs-input-label">Teljesítmény (kw)</span>
                            <span class="omrs-input-helper">P.2, szám</span>
                        </label>
                    </div>

                    <div class="omrs-input-group">
                        <label class="omrs-input-filled">
                            <input type="text" class="regex" name="gross_weight_kg" id="gross_weight_kg" required />
                            <span class="omrs-input-label">Együttes tömeg (kg)</span>
                            <span class="omrs-input-helper">F.1, szám</span>
                        </label>
                    </div>
                </div>
            
        </div>
        <div>
            <h4 class="title">Munka adatok:</h4>
                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <input type="text" maxlength="255" class="regex" name="repair_description" id="repair_description" required />
                        <span class="omrs-input-label">Munkaleírás</span>
                        <span class="omrs-input-helper">Max. 255 karakter</span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <select name="repair_type" id="repair_type" required>
                            <option value="null">Válassz:</option>
                            <option value="gumicsere">gumicsere</option>
                            <option value="olajcsere">olajcsere</option>
                            <option value="motorcsere">motorcsere</option>
                            <option value="szelvedocsere">szélvédő csere</option>
                        </select>
                        <span class="omrs-input-label">Munka kiválasztása</span>
                        <span class="omrs-input-helper"></span>
                    </label>
                </div>

                <div class="omrs-input-group">
                    <label class="omrs-input-filled">
                        <?php

                        include('dbconn.php');
                        $conn = connectionOpen();

                        $sql = "SELECT user_id, name FROM userTable WHERE user_role = 'Mechanic'";
                        $query = $conn->query($sql);

                        echo "<select name='repair_mechanic' id='repair_mechanic' required>";
                        echo "<option value='null'>Szerelő kiválasztása:</option>";

                        $i = 0;
                        while ($row = $query->fetch_assoc()) {
                            echo ++$i;
                            $name = $row['name'];
                            $userId = $row['user_id'];
                            echo '<option value="' . $userId . '">' . $name . '</option>';
                        }

                        echo "</select>";
                        connectionClose($conn);
                        ?>
                        <span class="omrs-input-label">Munka kiosztása</span>
                        <span class="omrs-input-helper"></span>
                    </label>
                </div>
                <div>
                    <button type="submit" onclick="submit" class="btn-wide btn-normal" name="submit">Beküldés</button>
                    <!-- <button type="submit" class="btn-insert" name="submit">SUBMIT</button> -->
                </div>
            </form>
        </div>
    </div>
</body>

</html>