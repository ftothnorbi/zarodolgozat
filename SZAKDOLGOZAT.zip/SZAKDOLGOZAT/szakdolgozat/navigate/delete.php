<?php
if (isset($_POST['checked'])) {
    foreach($_POST['checked'] as $checked) {
        echo $checked;
    }

    $_POST['checked'] = $checked;

    include('dbconn.php');
    $conn = connectionOpen();

    $del_sql = "UPDATE repair SET deleted = 1 WHERE car_id = '".$checked."' ";
    $del_run = mysqli_query($conn, $del_sql);

    if ($del_run) {
        echo "<h1>Form submitted successfully</h1>";
    }else {
        echo "<h1>Form not submitted successfully</h1>";
    }
    header("Location: ../home.php?page=newjob/delete");
    //TODO: visszairányítás!!
}