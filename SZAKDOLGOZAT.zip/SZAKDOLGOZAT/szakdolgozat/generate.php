<?php
    session_start();
    echo password_hash("admin", PASSWORD_DEFAULT);
    echo "<br/>";
    echo password_hash("szerelo", PASSWORD_DEFAULT);
    echo "<br/>";
    echo password_hash("munkafelvevo", PASSWORD_DEFAULT);
    echo "<br/>";
    echo password_hash("szerelo", PASSWORD_DEFAULT);
    session_destroy();
?>
<!-- új felhasználó hozzáadása:
    1. echo password_hash("<ide jön a jelszó>", PASSWORD_DEFAULT);
    2. Lefuttatod, amit kiírt hash-t kimásolod
    3. Adatbázisban a userTable-ben kitöltve lefuttatod:
       INSERT INTO username, password, name, email, user_role
       VALUES (<felhasználónév>, <kimásolt hash>, <teljes név>, <email>, <hozzáférés>);
    4. Kész!
-->