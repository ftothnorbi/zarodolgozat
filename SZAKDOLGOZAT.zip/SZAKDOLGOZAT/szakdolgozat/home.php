<?php
include "login.php";
#Ha nincs 'logged_in' session, visszairányítja a index.php ra
if (!isset($_SESSION['logged_in'])) {
     header('Location: index.php');
}

#Ha nincs 'login_user' session, visszairányítja az index.php ra
if (!isset($_SESSION['login_user'])) {
    header("location: index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/navigate.css">
    <link rel="stylesheet" href="css/newjob.css">
    <link rel="stylesheet" href="../css/">
    <title>Home</title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>
      </div>
      <div class="side-inner">

        <div class="profile">
          <?php
            switch ($_SESSION['user_role']) {
              case 'Administrator':
                echo '<img src="images/admin_avatar.jpg" alt="Image" class="img-fluid">';
                break;
              case 'Mechanic':
                echo '<img src="images/login_avatar.jpg" alt="Image" class="img-fluid">';
                break;
              case 'Manager':
                echo '<img src="images/manager_avatar.jpg" alt="Image" class="img-fluid">';
                break;
            }
          ?>
          <?php
            echo '<h3 class="name">'.$_SESSION['name'].'</h3>';
          ?>
          <?php
            echo '<span class="country">'.$_SESSION['user_role'].'</span>';
          ?>
        </div>

        
        <div class="nav-menu">
          <ul>
            <li><a href="?page=currjob"><span class="icon-home mr-3"></span>Jelenlegi Munkák</a></li>
            <li class="accordion">
              <a data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo" class="collapsible">
                <span class="icon-pie-chart mr-3"></span>Munkák szerkesztése
              </a>

              <div id="collapseTwo" class="collapse" aria-labelledby="headingOne">
                <div>
                  <ul>
                    <!-- %2F per jel ACII kodja -->
                    <li><a href="?page=newjob%2Fnew">Hozzáadás</a></li>
                    <li><a href="?page=newjob%2Fdelete">Törlés</a></li>
                    <li><a href="?page=newjob%2Fmodify">Módosítás</a></li>
                  </ul>
                </div>
              </div>

            </li>
            <li><a href="?page=service"><span class="icon-search2 mr-3"></span>Szervíz történet</a></li>
            <li><a href="?page=pwchange"><span class="icon-location-arrow mr-3"></span>Profil</a></li>
            <li><a href="logout.php" class="logout" onclick="return confirm('Biztosan ki akarsz jelentkezni?')"><span class="icon-sign-out mr-3"></span>Kijelentkezés</a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
      <div class="site-section">
        <div class="container">
          <div class="row justify-content-center">
          <?php
                if (isset($_GET['page'])) {
                    
                    switch ($_GET['page']) {
                        case 'currjob':
                            include('./navigate/currjob.php');
                            break;

                        case 'newjob/new':
                          if ($_SESSION['user_role']== 'Mechanic') {
                            echo '<h2>Nincs jogosultsága ehhez a művelethez!</h2>';
                          }else{
                            include('./navigate/newjob.php');
                          }
                            break;
                        case 'newjob/delete':
                          if ($_SESSION['user_role']== 'Mechanic') {
                            echo '<h2>Nincs jogosultsága ehhez a művelethez!</h2>';
                          }else{
                            include('./navigate/deletejob.php');
                          }
                            break;
                        case 'newjob/modify':
                          if ($_SESSION['user_role']== 'Mechanic') {
                            echo '<h2>Nincs jogosultsága ehhez a művelethez!</h2>';
                          }else{
                            include('./navigate/modifyjob.php');
                          }
                            break;

                        case 'service':
                            include('./navigate/service.php');
                            break;
                        case 'pwchange':
                            include('./navigate/pwchange.php');
                            break;
                        case 'currjob/currjobview';
                            include('./navigate/currjobview.php');
                            break;
                        default:
                            echo "switch default";
                            break;
                    }
                }  
            ?>
          </div>
        </div>
      </div>  
    </main>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>