<?php
session_start();
$error = "";
if (isset($_POST["submit"])) {
    if (empty($_POST["username-data"] || empty($_POST["password-data"]))) {
        $error = "<script>alert('Helytelen felhasználónév vagy jelszó')</script>";
    }else {
        $username = $_POST["username-data"];
        $password = $_POST["password-data"];

        $conn = mysqli_connect("localhost", "root", "", "garage");
        if (mysqli_connect_errno()) {
            echo "Adatbázis csatlakozási hiba";
        }
        $query = mysqli_query($conn, "SELECT user_id, username, password, user_role, name  FROM userTable WHERE username = '" . $username ."'");
        $result = mysqli_fetch_object($query);
                            //result osztály password változójára mutat
        if (password_verify($password, $result->password)) {
            $_SESSION['login_user'] = $username;
            $_SESSION['name'] = $result->name; //bejelentkezett felh. teljes neve-> kiirás navigációba
            $_SESSION['logged_in'] = true;
            $_SESSION['user_role'] = $result->user_role;
            $_SESSION['user_id'] = $result->user_id;
            //ellenorzes = user_role, ... (string), hozzáférés kezelése
            header("Location: home.php");
        }else {
            echo "<script>alert('Helytelen bejelentkezési felhasználónév vagy jelszó')</script>";
        }
    }
}
?>